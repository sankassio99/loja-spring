package com.example.lojaSpring.model.dao;

import ch.qos.logback.core.net.server.Client;
import com.example.lojaSpring.model.entity.Cliente;
import com.example.lojaSpring.model.entity.ClientePF;
import com.example.lojaSpring.model.entity.ClientePJ;
import com.example.lojaSpring.model.entity.ItemVenda;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import java.util.List;

@Repository
public class ClienteDao {

    @PersistenceContext
    private EntityManager em ;

    public void save(Cliente cliente){
        em.persist(cliente);
    }

    public List<ClientePF> clientesPF(){
        Query query = em.createQuery("from ClientePF");
        return query.getResultList();
    }

    public List<Cliente> clientes(){
        Query query = em.createQuery("from Cliente");
        return query.getResultList();
    }

    public List<ClientePJ> clientesPJ(){
        Query query = em.createQuery("from ClientePJ");
        return query.getResultList();
    }

}

